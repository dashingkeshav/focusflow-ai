const mongoose = require('mongoose');
const memoryStore = require('../utils/memoryStore');

const activityEventSchema = new mongoose.Schema(
  {
    userId: { type: String, required: true, index: true },
    sessionId: { type: String, required: true, index: true },
    eventType: {
      type: String,
      enum: ['tab_switch', 'idle', 'keyboard_burst', 'mouse_burst', 'camera_absent', 'camera_present', 'distraction_warning', 'domain_blocked'],
      required: true,
    },
    details: { type: String },
    domain: { type: String, default: null },
    warningNumber: { type: Number, default: null },
    timestamp: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

const ActivityEventModel = mongoose.model('ActivityEvent', activityEventSchema);

/**
 * Wrapper that provides fallback to in-memory store when MongoDB is unavailable
 */
const ActivityEventWithFallback = {
  create: async (data) => {
    try {
      return await ActivityEventModel.create(data);
    } catch (error) {
      console.warn(`[Memory Store] MongoDB unavailable, using memory store for create (ActivityEvent)`);
      return await memoryStore.create('activityEvents', data);
    }
  },

  find: async (filter) => {
    try {
      return await ActivityEventModel.find(filter);
    } catch (error) {
      console.warn(`[Memory Store] MongoDB unavailable, using memory store for find (ActivityEvent)`);
      return await memoryStore.find('activityEvents', filter);
    }
  }
};

module.exports = ActivityEventWithFallback;
