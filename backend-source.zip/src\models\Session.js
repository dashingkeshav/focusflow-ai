const { pool } = require("../config/db");


/*
 * Convert a PostgreSQL session row into the same
 * camelCase structure expected by the existing
 * controllers.
 */

function mapSession(row) {
  if (!row) {
    return null;
  }

  return {
    id: row.id,

    _id: row.id,

    userId: row.user_id,

    title: row.title,

    startTime: row.start_time
      ? new Date(row.start_time)
      : null,

    endTime: row.end_time
      ? new Date(row.end_time)
      : null,

    durationSeconds: Number(
      row.duration_seconds ?? 0
    ),

    avgFocusScore: Number(
      row.avg_focus_score ?? 100
    ),

    finalFocusScore:
      row.final_focus_score === null ||
      row.final_focus_score === undefined
        ? null
        : Number(row.final_focus_score),

    tabSwitches: Number(
      row.tab_switches ?? 0
    ),

    idleTimeSeconds: Number(
      row.idle_time_seconds ?? 0
    ),

    cameraDistractions: Number(
      row.camera_distractions ?? 0
    ),

    warningCount: Number(
      row.warning_count ?? 0
    ),

    blockedAttempts: Number(
      row.blocked_attempts ?? 0
    ),

    distractionEvents: Number(
      row.distraction_events ?? 0
    ),

    status: row.status,

    createdAt: row.created_at
      ? new Date(row.created_at)
      : null,

    updatedAt: row.updated_at
      ? new Date(row.updated_at)
      : null,
  };
}


/*
 * CREATE SESSION
 */

async function create(data = {}) {

  const userId = data.userId;

  if (!userId) {
    throw new Error(
      "Session userId is required."
    );
  }

  const title =
    data.title ??
    "Study Focus Session";

  const startTime =
    data.startTime ??
    new Date();

  const endTime =
    data.endTime ??
    null;

  const durationSeconds =
    data.durationSeconds ??
    0;

  const avgFocusScore =
    data.avgFocusScore ??
    100;

  const finalFocusScore =
    data.finalFocusScore ??
    null;

  const tabSwitches =
    data.tabSwitches ??
    0;

  const idleTimeSeconds =
    data.idleTimeSeconds ??
    0;

  const cameraDistractions =
    data.cameraDistractions ??
    0;

  const warningCount =
    data.warningCount ??
    0;

  const blockedAttempts =
    data.blockedAttempts ??
    0;

  const distractionEvents =
    data.distractionEvents ??
    0;

  const status =
    data.status ??
    "active";


  const result = await pool.query(
    `
    INSERT INTO sessions (
      user_id,
      title,
      start_time,
      end_time,
      duration_seconds,
      avg_focus_score,
      final_focus_score,
      tab_switches,
      idle_time_seconds,
      camera_distractions,
      warning_count,
      blocked_attempts,
      distraction_events,
      status
    )
    VALUES (
      $1,
      $2,
      $3,
      $4,
      $5,
      $6,
      $7,
      $8,
      $9,
      $10,
      $11,
      $12,
      $13,
      $14
    )
    RETURNING *
    `,
    [
      userId,
      title,
      startTime,
      endTime,
      durationSeconds,
      avgFocusScore,
      finalFocusScore,
      tabSwitches,
      idleTimeSeconds,
      cameraDistractions,
      warningCount,
      blockedAttempts,
      distractionEvents,
      status,
    ]
  );

  return mapSession(
    result.rows[0]
  );
}


/*
 * FIND ONE SESSION
 *
 * Supports:
 *
 * Session.findOne({
 *   userId: "...",
 *   status: "active"
 * })
 *
 * Session.findOne({
 *   _id: "..."
 * })
 */

async function findOne(filter = {}) {

  const conditions = [];

  const values = [];

  let index = 1;


  if (filter.id) {

    conditions.push(
      `id = $${index++}`
    );

    values.push(filter.id);
  }

  else if (filter._id) {

    conditions.push(
      `id = $${index++}`
    );

    values.push(filter._id);
  }


  if (filter.userId) {

    conditions.push(
      `user_id = $${index++}`
    );

    values.push(filter.userId);
  }


  if (filter.status) {

    conditions.push(
      `status = $${index++}`
    );

    values.push(filter.status);
  }


  if (conditions.length === 0) {

    throw new Error(
      "Session.findOne requires a filter."
    );
  }


  const query = `
    SELECT *
    FROM sessions
    WHERE ${conditions.join(" AND ")}
    ORDER BY created_at DESC
    LIMIT 1
  `;


  const result =
    await pool.query(
      query,
      values
    );


  return mapSession(
    result.rows[0]
  );
}


/*
 * FIND MANY
 */

async function find(filter = {}) {

  const conditions = [];

  const values = [];

  let index = 1;


  if (filter.userId) {

    conditions.push(
      `user_id = $${index++}`
    );

    values.push(filter.userId);
  }


  if (filter.status) {

    conditions.push(
      `status = $${index++}`
    );

    values.push(filter.status);
  }


  const whereClause =
    conditions.length > 0
      ? `WHERE ${conditions.join(" AND ")}`
      : "";


  const query = `
    SELECT *
    FROM sessions
    ${whereClause}
    ORDER BY start_time DESC
  `;


  const result =
    await pool.query(
      query,
      values
    );


  return result.rows.map(
    mapSession
  );
}


/*
 * FIND BY ID
 */

async function findById(id) {

  const result =
    await pool.query(
      `
      SELECT *
      FROM sessions
      WHERE id = $1
      LIMIT 1
      `,
      [id]
    );


  return mapSession(
    result.rows[0]
  );
}


/*
 * UPDATE ONE SESSION
 */

async function findOneAndUpdate(
  filter = {},
  update = {},
  options = {}
) {

  const session =
    await findOne(filter);


  if (!session) {

    if (
      options.new === false
    ) {
      return null;
    }

    return null;
  }


  const fields = [];

  const values = [];

  let index = 1;


  /*
   * Handle $set
   */

  const setData =
    update.$set || update;


  const mapping = {
    userId:
      "user_id",

    title:
      "title",

    startTime:
      "start_time",

    endTime:
      "end_time",

    durationSeconds:
      "duration_seconds",

    avgFocusScore:
      "avg_focus_score",

    finalFocusScore:
      "final_focus_score",

    tabSwitches:
      "tab_switches",

    idleTimeSeconds:
      "idle_time_seconds",

    cameraDistractions:
      "camera_distractions",

    warningCount:
      "warning_count",

    blockedAttempts:
      "blocked_attempts",

    distractionEvents:
      "distraction_events",

    status:
      "status",
  };


  for (
    const [
      key,
      value
    ] of Object.entries(setData)
  ) {

    if (
      Object.prototype.hasOwnProperty.call(
        mapping,
        key
      )
    ) {

      fields.push(
        `${mapping[key]} = $${index++}`
      );

      values.push(
        value
      );
    }
  }


  if (fields.length === 0) {
    return session;
  }


  fields.push(
    "updated_at = NOW()"
  );


  /*
   * Find primary ID
   */

  values.push(
    session.id
  );

  const idIndex =
    index++;


  const result =
    await pool.query(
      `
      UPDATE sessions
      SET
        ${fields.join(", ")}
      WHERE id = $${idIndex}
      RETURNING *
      `,
      values
    );


  return mapSession(
    result.rows[0]
  );
}


/*
 * UPDATE MANY
 */

async function updateMany(
  filter = {},
  update = {}
) {

  const conditions = [];

  const filterValues = [];

  let filterIndex = 1;


  if (filter.userId) {

    conditions.push(
      `user_id = $${filterIndex++}`
    );

    filterValues.push(
      filter.userId
    );
  }


  if (filter.status) {

    conditions.push(
      `status = $${filterIndex++}`
    );

    filterValues.push(
      filter.status
    );
  }


  if (
    conditions.length === 0
  ) {

    throw new Error(
      "updateMany requires a filter."
    );
  }


  const setData =
    update.$set || update;


  const setFields = [];

  const values = [
    ...filterValues
  ];

  let valueIndex =
    filterIndex;


  const mapping = {
    title:
      "title",

    startTime:
      "start_time",

    endTime:
      "end_time",

    durationSeconds:
      "duration_seconds",

    avgFocusScore:
      "avg_focus_score",

    finalFocusScore:
      "final_focus_score",

    tabSwitches:
      "tab_switches",

    idleTimeSeconds:
      "idle_time_seconds",

    cameraDistractions:
      "camera_distractions",

    warningCount:
      "warning_count",

    blockedAttempts:
      "blocked_attempts",

    distractionEvents:
      "distraction_events",

    status:
      "status",
  };


  for (
    const [
      key,
      value
    ] of Object.entries(setData)
  ) {

    if (
      Object.prototype.hasOwnProperty.call(
        mapping,
        key
      )
    ) {

      setFields.push(
        `${mapping[key]} = $${valueIndex++}`
      );

      values.push(value);
    }
  }


  if (setFields.length === 0) {

    return {
      acknowledged: true,
      modifiedCount: 0,
    };
  }


  setFields.push(
    "updated_at = NOW()"
  );


  const result =
    await pool.query(
      `
      UPDATE sessions
      SET
        ${setFields.join(", ")}
      WHERE ${conditions.join(" AND ")}
      `,
      values
    );


  return {
    acknowledged: true,

    modifiedCount:
      result.rowCount,
  };
}


/*
 * EXPORT
 */

module.exports = {
  create,
  findOne,
  find,
  findById,
  findOneAndUpdate,
  updateMany,
};