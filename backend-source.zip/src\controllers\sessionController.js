const Session = require('../models/Session');
const ActivityEvent = require('../models/ActivityEvent');

// POST /api/sessions/start
exports.startSession = async (req, res) => {
  try {
    // userId always comes from verified JWT token — never from request body
    const userId = req.user.id;
    const { title } = req.body;

    // Mark any previously active sessions for this user as cancelled
    // (handles tab-close recovery scenario)
    await Session.updateMany(
      { userId, status: 'active' },
      { $set: { status: 'cancelled', endTime: new Date() } }
    ).catch(() => null);

    const session = await Session.create({
      userId,
      title: title || 'Study Focus Session',
      startTime: new Date(),
      status: 'active',
    });

    return res.status(201).json({
      success: true,
      message: 'Focus session started',
      session,
    });
  } catch (error) {
    console.error('startSession error:', error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

// POST /api/sessions/end
exports.endSession = async (req, res) => {
  try {
    const userId = req.user.id;
    const {
      sessionId,
      durationSeconds,
      avgFocusScore,
      finalFocusScore,
      tabSwitches,
      idleTimeSeconds,
      cameraDistractions,
      warningCount,
      blockedAttempts,
      distractionEvents,
      status,
    } = req.body;

    if (!sessionId) {
      return res.status(400).json({ success: false, message: 'sessionId is required' });
    }

    // Only allow ending sessions that belong to the authenticated user
    const session = await Session.findOneAndUpdate(
      { _id: sessionId, userId },
      {
        endTime: new Date(),
        durationSeconds: durationSeconds || 0,
        avgFocusScore: avgFocusScore != null ? avgFocusScore : 0,
        finalFocusScore: finalFocusScore != null ? finalFocusScore : avgFocusScore,
        tabSwitches: tabSwitches || 0,
        idleTimeSeconds: idleTimeSeconds || 0,
        cameraDistractions: cameraDistractions || 0,
        warningCount: warningCount || 0,
        blockedAttempts: blockedAttempts || 0,
        distractionEvents: distractionEvents || 0,
        status: status || 'completed',
      },
      { new: true }
    );

    if (!session) {
      return res.status(404).json({
        success: false,
        message: 'Session not found or does not belong to you',
      });
    }

    return res.json({
      success: true,
      message: 'Session completed successfully',
      session,
    });
  } catch (error) {
    console.error('endSession error:', error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/sessions/history
exports.getSessionHistory = async (req, res) => {
  try {
    const userId = req.user.id;
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);

    let sessions = await Session.find({ userId });
    
    // Handle the memory store query object
    if (sessions && typeof sessions === 'object' && sessions.sort) {
      sessions = sessions.sort({ createdAt: -1 }).limit(limit).lean();
    } else {
      // Handle normal Mongoose query
      sessions = await sessions.sort({ createdAt: -1 }).limit(limit).lean();
    }

    return res.json({
      success: true,
      count: sessions.length,
      sessions,
    });
  } catch (error) {
    console.error('getSessionHistory error:', error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

// POST /api/sessions/event — record a distraction/activity event
exports.recordEvent = async (req, res) => {
  try {
    const userId = req.user.id;
    const { sessionId, eventType, details, domain, warningNumber } = req.body;

    if (!sessionId || !eventType) {
      return res.status(400).json({ success: false, message: 'sessionId and eventType are required' });
    }

    // Confirm session belongs to this user before recording event
    const session = await Session.findOne({ _id: sessionId, userId });
    if (!session) {
      return res.status(404).json({ success: false, message: 'Session not found or access denied' });
    }

    const event = await ActivityEvent.create({
      userId,
      sessionId,
      eventType,
      details,
      domain: domain || null,
      warningNumber: warningNumber || null,
      timestamp: new Date(),
    });

    return res.status(201).json({ success: true, event });
  } catch (error) {
    console.error('recordEvent error:', error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/sessions/active — get current active session for this user
exports.getActiveSession = async (req, res) => {
  try {
    const userId = req.user.id;

    const session = await Session.findOne({ userId, status: 'active' })
      .sort({ createdAt: -1 })
      .lean();

    return res.json({
      success: true,
      session: session || null,
    });
  } catch (error) {
    console.error('getActiveSession error:', error);
    return res.status(500).json({ success: false, message: error.message });
  }
};
