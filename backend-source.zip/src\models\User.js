const { pool } = require("../config/db");

/*
 * PostgreSQL User Model
 *
 * This replaces the old Mongoose User model.
 *
 * The returned user object keeps compatibility with the
 * existing authentication controllers by providing:
 *
 * - id
 * - _id
 * - save()
 */

function mapUser(row) {
  if (!row) {
    return null;
  }

  return {
    id: row.id,
    _id: row.id,

    name: row.name,
    email: row.email,
    password: row.password,

    dailyGoalHours: Number(row.daily_goal_hours ?? 4),
    streakDays: Number(row.streak_days ?? 5),

    resetToken: row.reset_token,
    resetTokenExpire: row.reset_token_expire
      ? new Date(row.reset_token_expire)
      : null,

    resetOTP: row.reset_otp,
    resetOTPExpire: row.reset_otp_expire
      ? new Date(row.reset_otp_expire)
      : null,

    lastLogin: row.last_login
      ? new Date(row.last_login)
      : null,

    emailVerified: Boolean(row.email_verified),

    createdAt: row.created_at
      ? new Date(row.created_at)
      : null,

    updatedAt: row.updated_at
      ? new Date(row.updated_at)
      : null,

    /*
     * Compatibility method for code that previously used:
     *
     * await user.save()
     */
    async save() {
      const result = await pool.query(
        `
        UPDATE users
        SET
          name = $1,
          email = $2,
          password = $3,
          daily_goal_hours = $4,
          streak_days = $5,
          reset_token = $6,
          reset_token_expire = $7,
          reset_otp = $8,
          reset_otp_expire = $9,
          last_login = $10,
          email_verified = $11,
          updated_at = NOW()
        WHERE id = $12
        RETURNING *
        `,
        [
          this.name,
          this.email,
          this.password,
          this.dailyGoalHours,
          this.streakDays,
          this.resetToken,
          this.resetTokenExpire,
          this.resetOTP,
          this.resetOTPExpire,
          this.lastLogin,
          this.emailVerified,
          this.id,
        ]
      );

      return mapUser(result.rows[0]);
    },
  };
}


/*
 * Find one user.
 *
 * Supported examples:
 *
 * UserModel.findOne({ email })
 * UserModel.findOne({ id })
 * UserModel.findOne({ _id })
 */
async function findOne(filter = {}) {
  let query = "";
  let value = null;

  if (filter.email) {
    query = `
      SELECT *
      FROM users
      WHERE email = LOWER($1)
      LIMIT 1
    `;

    value = String(filter.email).trim().toLowerCase();
  }

  else if (filter.id) {
    query = `
      SELECT *
      FROM users
      WHERE id = $1
      LIMIT 1
    `;

    value = filter.id;
  }

  else if (filter._id) {
    query = `
      SELECT *
      FROM users
      WHERE id = $1
      LIMIT 1
    `;

    value = filter._id;
  }

  else {
    throw new Error(
      "User.findOne requires a supported filter such as email or id."
    );
  }

  const result = await pool.query(
    query,
    [value]
  );

  return mapUser(result.rows[0]);
}


/*
 * Find user by ID.
 */
async function findById(id) {
  const result = await pool.query(
    `
    SELECT *
    FROM users
    WHERE id = $1
    LIMIT 1
    `,
    [id]
  );

  return mapUser(result.rows[0]);
}


/*
 * Create user.
 */
async function create(data = {}) {
  const name = String(data.name || "").trim();

  const email = String(data.email || "")
    .trim()
    .toLowerCase();

  const password = String(data.password || "");

  if (!name) {
    throw new Error("Name is required.");
  }

  if (!email) {
    throw new Error("Email is required.");
  }

  if (!password) {
    throw new Error("Password is required.");
  }

  const dailyGoalHours =
    data.dailyGoalHours ?? 4;

  const streakDays =
    data.streakDays ?? 5;

  const resetToken =
    data.resetToken ?? null;

  const resetTokenExpire =
    data.resetTokenExpire ?? null;

  const resetOTP =
    data.resetOTP ?? null;

  const resetOTPExpire =
    data.resetOTPExpire ?? null;

  const lastLogin =
    data.lastLogin ?? null;

  const emailVerified =
    data.emailVerified ?? false;


  const result = await pool.query(
    `
    INSERT INTO users (
      name,
      email,
      password,
      daily_goal_hours,
      streak_days,
      reset_token,
      reset_token_expire,
      reset_otp,
      reset_otp_expire,
      last_login,
      email_verified
    )
    VALUES (
      $1,
      LOWER($2),
      $3,
      $4,
      $5,
      $6,
      $7,
      $8,
      $9,
      $10,
      $11
    )
    RETURNING *
    `,
    [
      name,
      email,
      password,
      dailyGoalHours,
      streakDays,
      resetToken,
      resetTokenExpire,
      resetOTP,
      resetOTPExpire,
      lastLogin,
      emailVerified,
    ]
  );

  return mapUser(result.rows[0]);
}


module.exports = {
  findOne,
  findById,
  create,
};