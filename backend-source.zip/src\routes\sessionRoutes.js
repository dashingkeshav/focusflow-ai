const express = require('express');
const router = express.Router();
const sessionController = require('../controllers/sessionController');
const authMiddleware = require('../middleware/authMiddleware');

// All session routes require authentication
router.post('/start', authMiddleware, sessionController.startSession);
router.post('/end', authMiddleware, sessionController.endSession);
router.post('/event', authMiddleware, sessionController.recordEvent);
router.get('/active', authMiddleware, sessionController.getActiveSession);
router.get('/history', authMiddleware, sessionController.getSessionHistory);

module.exports = router;
