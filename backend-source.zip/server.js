require("dotenv").config();

const express = require("express");
const http = require("http");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const { Server } = require("socket.io");

const {
  testDatabaseConnection,
} = require("./src/config/db");

// API routes
const authRoutes = require("./src/routes/authRoutes");
const sessionRoutes = require("./src/routes/sessionRoutes");
const focusRoutes = require("./src/routes/focusRoutes");
const analyticsRoutes = require("./src/routes/analyticsRoutes");

const app = express();
const server = http.createServer(app);

// =====================================================
// CONFIGURATION
// =====================================================

const PORT = Number(process.env.PORT) || 5001;

const FRONTEND_URL =
  process.env.FRONTEND_URL ||
  "http://localhost:3000";

const JWT_SECRET =
  process.env.JWT_SECRET ||
  "focusflow_ai_phase2_secret_key_2026";

// =====================================================
// CORS
// =====================================================

app.use(
  cors({
    origin: FRONTEND_URL,
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: [
      "Content-Type",
      "Authorization",
    ],
  })
);

// =====================================================
// BODY PARSER
// =====================================================

app.use(
  express.json({
    limit: "2mb",
  })
);

// =====================================================
// SOCKET.IO
// =====================================================

const io = new Server(server, {
  cors: {
    origin: FRONTEND_URL,
    methods: ["GET", "POST"],
    credentials: true,
  },
});

// Make io accessible from controllers if needed
app.set("io", io);

// =====================================================
// SOCKET AUTHENTICATION
// =====================================================

io.use((socket, next) => {
  try {
    const token =
      socket.handshake.auth?.token ||
      socket.handshake.headers?.authorization?.split(" ")[1];

    if (!token) {
      return next(
        new Error("Authentication required")
      );
    }

    const decoded = jwt.verify(
      token,
      JWT_SECRET
    );

    /*
     * Support the user's existing JWT structure.
     * Existing auth code may use decoded.id and decoded.email.
     */

    socket.userId = decoded.id;
    socket.userEmail = decoded.email;

    if (!socket.userId) {
      return next(
        new Error("Invalid authentication token")
      );
    }

    next();

  } catch (error) {
    console.error(
      "[Socket.io] Authentication failed:",
      error.message
    );

    next(
      new Error("Invalid or expired token")
    );
  }
});

// =====================================================
// SOCKET CONNECTION
// =====================================================

io.on("connection", (socket) => {

  const userId = socket.userId;

  console.log(
    `[Socket.io] User ${userId} connected (socket ${socket.id})`
  );

  /*
   * Every user gets their own room.
   * This prevents telemetry from leaking between users.
   */

  socket.join(`user:${userId}`);

  // ---------------------------------------------------
  // TELEMETRY
  // ---------------------------------------------------

  socket.on(
    "telemetry_signal",
    (data = {}) => {

      try {

        const tabSwitches =
          typeof data.tabSwitches === "number"
            ? Math.max(0, data.tabSwitches)
            : 0;

        const idleTimeSeconds =
          typeof data.idleTimeSeconds === "number"
            ? Math.max(0, data.idleTimeSeconds)
            : 0;

        const keyboardRate =
          typeof data.keyboardRate === "number"
            ? Math.max(0, data.keyboardRate)
            : 0;

        const mouseRate =
          typeof data.mouseRate === "number"
            ? Math.max(0, data.mouseRate)
            : 0;

        const cameraDistractions =
          typeof data.cameraDistractions === "number"
            ? Math.max(0, data.cameraDistractions)
            : 0;

        const sessionId =
          typeof data.sessionId === "string"
            ? data.sessionId
            : null;


        // =============================================
        // FOCUS SCORE
        // =============================================

        let score = 100;

        score -= tabSwitches * 4;

        score -= cameraDistractions * 10;

        score -=
          Math.floor(idleTimeSeconds / 10) * 1.5;

        /*
         * Small positive signals.
         * Keep score deterministic.
         */

        if (
          keyboardRate > 15 &&
          keyboardRate < 120
        ) {
          score += 5;
        }

        if (
          mouseRate > 5 &&
          mouseRate < 60
        ) {
          score += 3;
        }

        score = Math.max(
          0,
          Math.min(
            100,
            Math.round(score)
          )
        );


        // =============================================
        // DISTRACTION STATE
        // =============================================

        const isDistracted =
          tabSwitches >= 5 ||
          cameraDistractions >= 2 ||
          idleTimeSeconds >= 120 ||
          score < 65;


        // =============================================
        // ALERT MESSAGE
        // =============================================

        let alertMessage = null;

        if (cameraDistractions >= 2) {

          alertMessage =
            `Camera alert: ${cameraDistractions} look-away events detected.`;

        } else if (tabSwitches >= 5) {

          alertMessage =
            `High tab-switching rate detected (${tabSwitches} switches).`;

        } else if (idleTimeSeconds >= 120) {

          alertMessage =
            `Inactivity detected for ${Math.floor(
              idleTimeSeconds / 60
            )} minutes.`;

        } else if (score < 65) {

          alertMessage =
            `Focus score dropped to ${score}. Return to your study task.`;
        }


        const payload = {
          timestamp: Date.now(),

          userId,

          sessionId,

          score,

          isDistracted,

          alertMessage,

          tabSwitches,

          idleTimeSeconds,

          cameraDistractions,
        };


        /*
         * Emit only to this user's room.
         */

        io
          .to(`user:${userId}`)
          .emit(
            "focus_score_update",
            payload
          );

      } catch (error) {

        console.error(
          "[Socket.io] Telemetry error:",
          error
        );
      }
    }
  );


  // ---------------------------------------------------
  // DISTRACTION WARNING
  // ---------------------------------------------------

  socket.on(
    "distraction_warning",
    (data = {}) => {

      const warningNumber =
        Number.isInteger(data.warningNumber)
          ? data.warningNumber
          : 1;

      const payload = {
        userId,

        sessionId:
          typeof data.sessionId === "string"
            ? data.sessionId
            : null,

        warningNumber,

        reason:
          typeof data.reason === "string"
            ? data.reason
            : "Distraction detected",

        timestamp: Date.now(),
      };


      io
        .to(`user:${userId}`)
        .emit(
          "distraction_warning",
          payload
        );
    }
  );


  // ---------------------------------------------------
  // BLOCKING ACTIVATED
  // ---------------------------------------------------

  socket.on(
    "blocking_activated",
    (data = {}) => {

      const payload = {
        userId,

        sessionId:
          typeof data.sessionId === "string"
            ? data.sessionId
            : null,

        domain:
          typeof data.domain === "string"
            ? data.domain
            : null,

        timestamp: Date.now(),
      };


      io
        .to(`user:${userId}`)
        .emit(
          "blocking_activated",
          payload
        );
    }
  );


  // ---------------------------------------------------
  // FOCUS SESSION STARTED
  // ---------------------------------------------------

  socket.on(
    "focus_session_started",
    (data = {}) => {

      io
        .to(`user:${userId}`)
        .emit(
          "focus_session_started",
          {
            userId,

            sessionId:
              typeof data.sessionId === "string"
                ? data.sessionId
                : null,

            timestamp: Date.now(),
          }
        );
    }
  );


  // ---------------------------------------------------
  // FOCUS SESSION ENDED
  // ---------------------------------------------------

  socket.on(
    "focus_session_ended",
    (data = {}) => {

      io
        .to(`user:${userId}`)
        .emit(
          "focus_session_ended",
          {
            userId,

            sessionId:
              typeof data.sessionId === "string"
                ? data.sessionId
                : null,

            timestamp: Date.now(),
          }
        );
    }
  );


  // ---------------------------------------------------
  // DISCONNECT
  // ---------------------------------------------------

  socket.on(
    "disconnect",
    (reason) => {

      console.log(
        `[Socket.io] User ${userId} disconnected ` +
        `(socket ${socket.id}) - ${reason}`
      );
    }
  );
});

// =====================================================
// HTTP API ROUTES
// =====================================================

app.use(
  "/api/auth",
  authRoutes
);

app.use(
  "/api/sessions",
  sessionRoutes
);

app.use(
  "/api/focus",
  focusRoutes
);

app.use(
  "/api/analytics",
  analyticsRoutes
);

// =====================================================
// HEALTH CHECK
// =====================================================

app.get(
  "/api/health",
  async (req, res) => {

    res.status(200).json({
      status: "healthy",

      system:
        "FocusFlow AI Backend",

      database:
        "Supabase PostgreSQL",

      timestamp:
        new Date().toISOString(),

      version:
        "3.0.0",
    });
  }
);

// =====================================================
// 404 HANDLER
// =====================================================

app.use(
  (req, res) => {

    res.status(404).json({
      success: false,
      error:
        `Route not found: ${req.method} ${req.originalUrl}`,
    });
  }
);

// =====================================================
// GLOBAL ERROR HANDLER
// =====================================================

app.use(
  (error, req, res, next) => {

    console.error(
      "[HTTP ERROR]",
      error
    );

    if (res.headersSent) {
      return next(error);
    }

    res.status(
      error.status || 500
    ).json({
      success: false,

      error:
        process.env.NODE_ENV === "production"
          ? "Internal server error."
          : error.message ||
            "Internal server error.",
    });
  }
);

// =====================================================
// START SERVER
// =====================================================

async function startServer() {

  try {

    console.log(
      "================================================="
    );

    console.log(
      "🚀 Starting FocusFlow AI Backend..."
    );

    console.log(
      "================================================="
    );


    // -----------------------------------------------
    // TEST SUPABASE DATABASE
    // -----------------------------------------------

    await testDatabaseConnection();


    // -----------------------------------------------
    // START HTTP SERVER
    // -----------------------------------------------

    server.listen(
      PORT,
      () => {

        console.log(
          "================================================="
        );

        console.log(
          `🚀 FocusFlow AI Backend running on port ${PORT}`
        );

        console.log(
          `🌐 API: http://localhost:${PORT}/api`
        );

        console.log(
          `❤️ Health: http://localhost:${PORT}/api/health`
        );

        console.log(
          `🌐 Frontend: ${FRONTEND_URL}`
        );

        console.log(
          "🗄️ Database: Supabase PostgreSQL"
        );

        console.log(
          "🔐 JWT authentication: enabled"
        );

        console.log(
          "🔌 Socket.io: enabled"
        );

        console.log(
          "================================================="
        );
      }
    );

  } catch (error) {

    console.error(
      "================================================="
    );

    console.error(
      "❌ BACKEND STARTUP FAILED"
    );

    console.error(
      "================================================="
    );

    console.error(
      error.message
    );

    process.exit(1);
  }
}


// =====================================================
// SERVER ERROR
// =====================================================

server.on(
  "error",
  (error) => {

    console.error(
      "❌ Server startup error:",
      error
    );

    process.exit(1);
  }
);


// =====================================================
// GRACEFUL SHUTDOWN
// =====================================================

async function shutdown(signal) {

  console.log(
    `\n${signal} received. Shutting down...`
  );

  server.close(() => {

    console.log(
      "✅ HTTP server closed."
    );

    process.exit(0);
  });
}

process.on(
  "SIGINT",
  () => shutdown("SIGINT")
);

process.on(
  "SIGTERM",
  () => shutdown("SIGTERM")
);


// =====================================================
// START
// =====================================================

startServer();