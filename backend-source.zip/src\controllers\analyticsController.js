const Session = require('../models/Session');
const ActivityEvent = require('../models/ActivityEvent');

// GET /api/analytics/dashboard
// Returns all stats the dashboard needs for the authenticated user.
exports.getDashboardStats = async (req, res) => {
  try {
    const userId = req.user.id;

    // Date range helpers
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const sevenDaysAgo = new Date(startOfToday);
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);

    // ── All-time completed sessions for this user ──────────────────────
    let allSessions = await Session.find({
      userId,
      status: 'completed',
    });
    
    // Handle the memory store query object
    if (allSessions && typeof allSessions === 'object' && allSessions.sort) {
      allSessions = allSessions.sort({ createdAt: -1 }).lean();
    } else {
      // Handle normal Mongoose query
      allSessions = await allSessions.sort({ createdAt: -1 }).lean();
    }

    // ── Today's sessions ───────────────────────────────────────────────
    const todaySessions = allSessions.filter(
      (s) => new Date(s.startTime) >= startOfToday
    );

    // ── Aggregated totals ──────────────────────────────────────────────
    const totalStudySeconds = allSessions.reduce(
      (sum, s) => sum + (s.durationSeconds || 0),
      0
    );
    const todayStudySeconds = todaySessions.reduce(
      (sum, s) => sum + (s.durationSeconds || 0),
      0
    );
    const totalWarnings = allSessions.reduce(
      (sum, s) => sum + (s.warningCount || 0),
      0
    );
    const totalBlocked = allSessions.reduce(
      (sum, s) => sum + (s.blockedAttempts || 0),
      0
    );
    const totalCameraDistractions = allSessions.reduce(
      (sum, s) => sum + (s.cameraDistractions || 0),
      0
    );
    const totalTabSwitches = allSessions.reduce(
      (sum, s) => sum + (s.tabSwitches || 0),
      0
    );

    // ── Average focus score (all completed sessions) ────────────────────
    const avgFocusScore =
      allSessions.length > 0
        ? Math.round(
            allSessions.reduce((sum, s) => sum + (s.avgFocusScore || 0), 0) /
              allSessions.length
          )
        : 0;

    const bestFocusScore =
      allSessions.length > 0
        ? Math.max(...allSessions.map((s) => s.avgFocusScore || 0))
        : 0;

    // ── Daily streak calculation ───────────────────────────────────────
    // A day counts if at least one session was completed on it.
    const sessionDays = new Set(
      allSessions.map((s) =>
        new Date(s.startTime).toISOString().slice(0, 10)
      )
    );
    let streakDays = 0;
    const checkDate = new Date(startOfToday);
    while (sessionDays.has(checkDate.toISOString().slice(0, 10))) {
      streakDays++;
      checkDate.setDate(checkDate.getDate() - 1);
    }

    // ── Weekly chart data (last 7 days) ────────────────────────────────
    const weeklyData = [];
    for (let i = 6; i >= 0; i--) {
      const dayStart = new Date(startOfToday);
      dayStart.setDate(dayStart.getDate() - i);
      const dayEnd = new Date(dayStart);
      dayEnd.setDate(dayEnd.getDate() + 1);

      const daySessions = allSessions.filter(
        (s) =>
          new Date(s.startTime) >= dayStart &&
          new Date(s.startTime) < dayEnd
      );

      const dayLabel = dayStart.toLocaleDateString('en-US', { weekday: 'short' });
      const dayHours = parseFloat(
        (daySessions.reduce((sum, s) => sum + (s.durationSeconds || 0), 0) / 3600).toFixed(1)
      );
      const dayScore =
        daySessions.length > 0
          ? Math.round(
              daySessions.reduce((sum, s) => sum + (s.avgFocusScore || 0), 0) /
                daySessions.length
            )
          : 0;
      const dayCameraEvents = daySessions.reduce(
        (sum, s) => sum + (s.cameraDistractions || 0),
        0
      );
      const dayTabViolations = daySessions.reduce(
        (sum, s) => sum + (s.tabSwitches || 0),
        0
      );
      const dayIdleTime = Math.round(
        daySessions.reduce((sum, s) => sum + (s.idleTimeSeconds || 0), 0) / 60
      );

      weeklyData.push({
        day: dayLabel,
        hours: dayHours,
        score: dayScore,
        cameraEvents: dayCameraEvents,
        tabViolations: dayTabViolations,
        idleTime: dayIdleTime,
      });
    }

    // ── Recent session timeline (last session's mini snapshots) ────────
    // We don't store per-minute snapshots yet, so we return session-level data.
    const recentTimeline = allSessions.slice(0, 10).map((s) => ({
      time: new Date(s.startTime).toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
      }),
      score: s.avgFocusScore || 0,
      camera: s.cameraDistractions || 0,
      tabSwitch: s.tabSwitches || 0,
    }));

    // ── Distraction breakdown ───────────────────────────────────────────
    const totalDistractionEvents =
      totalCameraDistractions + totalTabSwitches + totalWarnings;
    const distractionBreakdown =
      totalDistractionEvents > 0
        ? [
            {
              name: 'Camera Look-Away',
              value: Math.round((totalCameraDistractions / totalDistractionEvents) * 100),
              color: '#06b6d4',
            },
            {
              name: 'Tab Switches',
              value: Math.round((totalTabSwitches / totalDistractionEvents) * 100),
              color: '#f43f5e',
            },
            {
              name: 'Warnings Issued',
              value: Math.round((totalWarnings / totalDistractionEvents) * 100),
              color: '#f59e0b',
            },
          ]
        : [];

    return res.json({
      success: true,
      stats: {
        avgFocusScore,
        bestFocusScore,
        totalStudySeconds,
        todayStudySeconds,
        totalSessions: allSessions.length,
        totalWarnings,
        totalBlocked,
        totalCameraDistractions,
        totalTabSwitches,
        streakDays,
        weeklyData,
        recentTimeline,
        distractionBreakdown,
        recentSessions: allSessions.slice(0, 5),
      },
    });
  } catch (error) {
    console.error('getDashboardStats error:', error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

// GET /api/analytics/me — authenticated user profile
exports.getMe = async (req, res) => {
  try {
    const User = require('../models/User');
    const user = await User.findById(req.user.id);

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    return res.json({
      success: true,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        initials: user.name.slice(0, 2).toUpperCase(),
        dailyGoalHours: user.dailyGoalHours || 4,
        createdAt: user.createdAt,
      },
    });
  } catch (error) {
    console.error('getMe error:', error);
    return res.status(500).json({ success: false, message: error.message });
  }
};

// PUT /api/analytics/me — update profile
exports.updateMe = async (req, res) => {
  try {
    const User = require('../models/User');
    const bcrypt = require('bcryptjs');
    const { validateEmail, sanitizeEmail, getPasswordErrors } = require('../utils/validation');

    const { name, email, currentPassword, newPassword } = req.body;
    const userId = req.user.id;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    // Update name
    if (name && name.trim().length >= 2) {
      user.name = name.trim();
    }

    // Update email
    if (email) {
      if (!validateEmail(email)) {
        return res.status(400).json({ success: false, message: 'Invalid email address' });
      }
      const sanitized = sanitizeEmail(email);
      const existing = await User.findOne({ email: sanitized });
      if (existing && existing._id.toString() !== userId) {
        return res.status(400).json({ success: false, message: 'Email already in use by another account' });
      }
      user.email = sanitized;
    }

    // Update password
    if (newPassword) {
      if (!currentPassword) {
        return res.status(400).json({ success: false, message: 'Current password is required to set a new password' });
      }
      const valid = await bcrypt.compare(currentPassword, user.password);
      if (!valid) {
        return res.status(401).json({ success: false, message: 'Current password is incorrect' });
      }
      const errors = getPasswordErrors(newPassword);
      if (errors.length > 0) {
        return res.status(400).json({ success: false, message: errors[0] });
      }
      user.password = await bcrypt.hash(newPassword, 10);
    }

    await user.save();

    return res.json({
      success: true,
      message: 'Profile updated successfully',
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        initials: user.name.slice(0, 2).toUpperCase(),
        dailyGoalHours: user.dailyGoalHours || 4,
      },
    });
  } catch (error) {
    console.error('updateMe error:', error);
    return res.status(500).json({ success: false, message: error.message });
  }
};
