const express = require('express');
const router = express.Router();
const analyticsController = require('../controllers/analyticsController');
const authMiddleware = require('../middleware/authMiddleware');

// All analytics routes require authentication
router.get('/dashboard', authMiddleware, analyticsController.getDashboardStats);
router.get('/me', authMiddleware, analyticsController.getMe);
router.put('/me', authMiddleware, analyticsController.updateMe);

module.exports = router;
