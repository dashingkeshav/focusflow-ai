const { Pool } = require("pg");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false,
  },
});

pool.on("connect", () => {
  console.log("✅ Connected to Supabase PostgreSQL");
});

pool.on("error", (error) => {
  console.error("❌ Supabase PostgreSQL error:", error);
});

async function testDatabaseConnection() {
  try {
    const result = await pool.query("SELECT NOW()");
    console.log(
      "✅ Database connection successful:",
      result.rows[0]
    );
  } catch (error) {
    console.error(
      "❌ Database connection failed:",
      error.message
    );
    throw error;
  }
}

module.exports = {
  pool,
  testDatabaseConnection,
};