const express = require('express');
const router = express.Router();
const focusController = require('../controllers/focusController');
const authMiddleware = require('../middleware/authMiddleware');

// Focus score calculation requires authentication so we can tie scores to users
router.post('/calculate', authMiddleware, focusController.calculateFocusScore);

module.exports = router;
